//
//  ContentView.swift
//  Perfil
//
//  Created by Turma02-9 on 26/02/25.
//

import SwiftUI

struct Cadastro: Identifiable{
    var id: Int;
    var name: String;
    var cpf: String;
    var telefone: String;
    var endereco: String;
    var cidade: String;
    var estado: String;
    var cep: String;
    var edit: String;
    var minhasConversas: String;
    var favoritos: String;
}

struct ContentView: View {
    
    var arrayPerfil = [Cadastro(id: 1, name: "Henrique Juliano", cpf: "111.111.111-11" , telefone: "(34) 9900-000", endereco:"Rua zero, 01 - Barro Número", cidade: "Monte Carmelo", estado: "MG", cep: "38500-000", edit: "Pedreiro com experiencia em acabamento", minhasConversas: "Prestação de serviço de pintura no bairro Trevo", favoritos: "Pintura em epoxi")]
    
    var body: some View {
        
            
        ZStack{
            VStack {
                HStack{
                    Text("MEU PERFIL").foregroundColor(.black).font(.system(size: 26)).bold()
                    Spacer()
                }
                        HStack{
                            ForEach(arrayPerfil) { cadastro in
                                VStack{
                                    HStack{
                                        Image(systemName: "person.circle.fill").resizable().scaledToFit().frame(width: 100)
                                        VStack(alignment: .leading){
                                            /*@START_MENU_TOKEN@*/Text(cadastro.name)/*@END_MENU_TOKEN@*/
                                            Text(cadastro.cpf)
                                            Text(cadastro.telefone)
                                            Text(cadastro.endereco)
                                            HStack{
                                                Text(cadastro.cep)
                                                Text(cadastro.cidade)
                                                Text(cadastro.estado)
                                            }
                                        }.foregroundColor(.black)
                                    }
                                    Spacer()
                                    VStack(alignment: .leading, spacing:25){
                                        HStack{
                                            Text(cadastro.edit)
                                            Spacer()
                                        }.frame(width: 300).padding().background(.gray)
                                            .cornerRadius(30)
                                        HStack{
                                            Text(cadastro.minhasConversas)
                                            Spacer()
                                        }.frame(width: 300).padding().background(.gray)
                                            .cornerRadius(30)
                                        HStack{
                                            Text(cadastro.favoritos)
                                            Spacer()
                                        }.frame(width: 300).padding().background(.gray)
                                            .cornerRadius(30)
                                    }.foregroundColor(.black).font(.system(size: 24))
                                    Spacer()
                                    VStack{
                                        HStack{
                                            Image(systemName: "questionmark.circle").resizable().scaledToFit().frame(width: 30)
                                            Button(action: /*@START_MENU_TOKEN@*/{}/*@END_MENU_TOKEN@*/, label: {
                                                Text ("Ajuda").foregroundColor(.black).font(.system(size: 20))
                                            })
                                        }.position(x: 45)
                                        HStack{
                                            Image(systemName: "gearshape").resizable().scaledToFit().frame(width: 30)
                                            Button(action: /*@START_MENU_TOKEN@*/{}/*@END_MENU_TOKEN@*/, label: {
                                                Text ("Configurações").foregroundColor(.black).font(.system(size: 20))
                                            })
                                        }.position(x: 85)
                                        HStack{
                                            Image(systemName: "rectangle.portrait.and.arrow.forward").resizable().scaledToFit().frame(width: 30)
                                            Button(action: /*@START_MENU_TOKEN@*/{}/*@END_MENU_TOKEN@*/, label: {
                                                Text ("Sair").foregroundColor(.black).font(.system(size: 20))
                                            })
                                        }.position(x: 45)
                                    }.frame(height:150)
                                }
                            }
                        }

                    }
            }
    }
}

#Preview {
    ContentView()
}
