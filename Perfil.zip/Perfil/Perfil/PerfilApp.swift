//
//  PerfilApp.swift
//  Perfil
//
//  Created by Turma02-9 on 26/02/25.
//

import SwiftUI

@main
struct PerfilApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
